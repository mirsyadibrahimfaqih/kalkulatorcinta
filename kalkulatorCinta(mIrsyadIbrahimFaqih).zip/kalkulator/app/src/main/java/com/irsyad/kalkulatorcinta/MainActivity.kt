package com.irsyad.kalkulatorcinta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextPertama: EditText = findViewById(R.id.etvalue1);
        val editTextKedua: EditText = findViewById(R.id.etvalue2);
        val tvValue : TextView = findViewById(R.id.tvValue);


        val btnKalkulasi: Button = findViewById(R.id.btnKalkulasi);

        btnKalkulasi.setOnClickListener {
            val randomValue = String.format("%.2f", 1.00 + Random.nextDouble() * (100.00 - 1.00));
            val person1 = editTextPertama.text.toString();
            val person2 = editTextKedua.text.toString();

            // Konversi randomValue ke tipe data Double
            val persentase = randomValue.toDouble()

            // Periksa kondisi dan tampilkan pesan yang sesuai
            val pesan = when {
                persentase < 60 -> "Tidak Cocok"
                persentase < 80 -> "Cocok"
                else -> "Sangat Cocok"
            }

            // Tampilkan hasilnya di TextView
            tvValue.text = "$randomValue%\n$pesan"

            // Opsional, tampilkan pesan Toast
            Toast.makeText(this, "Hasil Kalkulasi: $pesan", Toast.LENGTH_SHORT).show()
        }

    }
}